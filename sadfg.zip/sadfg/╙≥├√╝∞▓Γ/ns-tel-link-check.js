const axios = require('axios');
const fs = require('fs');
const path = require('path');

// ====== 配置区 ======
const API_KEY = '';
const TELEGRAM_TOKEN = '';
const TELEGRAM_CHAT_ID = '-';
//const TELEGRAM_CHAT_ID = '';
const TELEGRAM_API_URL = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`;
const LINKS_FILE = path.join(__dirname, 'ns-domain-links.txt');
const CONCURRENCY = 6;
const HTTP_TIMEOUT = 8000;

// ====== 工具函数 ======
function isMainDomain(hostname) {
  const parts = hostname.split('.');
  return parts.length === 2 || (parts.length === 3 && parts[1].length <= 3);
}


function generateVariants(urlOrHost) {
  let host = urlOrHost.trim();
  if (!/^https?:\/\//.test(host)) host = 'https://' + host;
  return [host];
}

async function sendTelegramMessage(text) {
  try {
    await axios.post(TELEGRAM_API_URL, {
      chat_id: TELEGRAM_CHAT_ID,
      text,
      parse_mode: 'Markdown'
    }, { timeout: 5000 });
  } catch (err) {
    console.error('❌ 发送 Telegram 消息失败：', err.message);
  }
}

async function checkGoogleSafe(url) {
  if (!API_KEY) return false;
  try {
    const res = await axios.post(
      `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEY}`,
      {
        client: { clientId: "domain-checker", clientVersion: "1.0.0" },
        threatInfo: {
          threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
          platformTypes: ["ANY_PLATFORM"],
          threatEntryTypes: ["URL"],
          threatEntries: [{ url }]
        }
      },
      { timeout: 8000 }
    );
    return !!(res.data && res.data.matches);
  } catch (err) {
    console.error(`Google Safe 检测失败: ${url} -> ${err.message}`);
    return false;
  }
}

async function checkHttpAccessible(url) {
  try {
    const res = await axios.get(url, {
      maxRedirects: 5,
      timeout: HTTP_TIMEOUT,
      validateStatus: () => true
    });
    return res.status >= 200 && res.status < 400;
  } catch {
    return false;
  }
}

function suggestionByIndex(i, chainLength) {
  if (chainLength === 1 || i === 0) return '请更换此链路的推广链接';
  if (i === 1) return '请更换此链路的买家链接';
  if (i === 2) return '请更换此链路的卖家链接';
  return '请更换对应链接';
}

function parseLinksFile(filepath) {
  const raw = fs.readFileSync(filepath, 'utf-8');
  const lines = raw.split(/\r?\n/);
  const projects = {};
  let current = '未分组';
  for (let line of lines) {
    line = line.trim();
    if (!line) continue;
    const m = line.match(/^\[(.+?)\]$/);
    if (m) {
      current = m[1];
      continue;
    }
    const parts = line.split('->').map(s => s.trim()).filter(Boolean);
    if (!parts.length) continue;
    if (!projects[current]) projects[current] = [];
    projects[current].push(parts);
  }
  return projects;
}

async function runBatches(tasks, size = 10) {
  const results = [];
  for (let i = 0; i < tasks.length; i += size) {
    const batch = tasks.slice(i, i + size).map(fn => fn());
    const res = await Promise.all(batch);
    results.push(...res);
  }
  return results;
}


async function checkChain(chain) {
  const results = [];
  for (let i = 0; i < chain.length; i++) {
    const host = chain[i];
    const url = generateVariants(host)[0];
    const isRed = await checkGoogleSafe(url);
    const accessible = await checkHttpAccessible(url);
    results.push({ host, idx: i, isRed, accessible });
  }
  return results;
}

function formatProjectReport(project, chainsResults) {
  let hasIssue = false;
  const bads = [];
  const reds = [];

  for (const c of chainsResults) {
    const chainStr = c.chain.join(' → ');
    for (const d of c.domainResults) {
      if (!d.accessible) {
        hasIssue = true;
        hasIssue = true;
        bads.push({ host: d.host, chainStr, idx: d.idx, chainLength: c.chain.length });
      }
      if (d.isRed) {
        hasIssue = true;
        reds.push({ host: d.host, chainStr, idx: d.idx, chainLength: c.chain.length });
      }
    }
  }

  let msg = `📦 *${project} 检测结果：*\n\n`;
  //if (!hasIssue) return msg + '本次检测域名 无异常 ✅';
  if (!hasIssue) return '';

 // 过滤掉已经在爆红列表里的域名，避免重复输出
  const badsFiltered = bads.filter(b => !reds.some(r => r.host === b.host));

  if (bads.length) {
    msg += '📡 *访问异常：*\n';
    for (const b of bads) {
      msg += `${b.host}\n`;
      msg += `对应链路：\n${b.chainStr}\n`;
      //msg += `${suggestionByIndex(b.idx, b.chainLength)}\n\n`;
      msg += `请再次检查确认\n\n`;
    }
  }

  if (reds.length) {
    msg += '🚨 *爆红：*\n';
    for (const r of reds) {
      msg += `${r.host}\n`;
      msg += `对应链路：\n${r.chainStr}\n`;
      msg += `${suggestionByIndex(r.idx, r.chainLength)}\n\n`;
    }
  }
  return msg.trim();
}

// ====== 主流程 ======
(async () => {
  try {
    if (!fs.existsSync(LINKS_FILE)) {
      console.error(`❌ 未找到文件：${LINKS_FILE}`);
      process.exit(1);
    }

    const projects = parseLinksFile(LINKS_FILE);
    const names = Object.keys(projects);
    const tasks = names.map(name => async () => {
      const chains = projects[name];
      const chainTasks = chains.map(chain => async () => {
        const domainResults = await checkChain(chain);
        return { chain, domainResults };
      });
      const chainsResults = await runBatches(chainTasks, Math.max(1, Math.floor(CONCURRENCY / Math.max(1, names.length))));
      const report = formatProjectReport(name, chainsResults);
    /*
      console.log('='.repeat(40));
      console.log(report);
      console.log('='.repeat(40));
      await sendTelegramMessage(report);
      */
      if (report) {
        console.log('='.repeat(40));
        console.log(report);
        console.log('='.repeat(40));
        await sendTelegramMessage(report);
      }
    });

    await runBatches(tasks, CONCURRENCY);
    console.log('✅ 所有项目检测完成。');
  } catch (err) {
    console.error('❌ 主流程出错：', err);
  }
})();
