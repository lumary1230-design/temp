const axios = require('axios');
const fs = require('fs');
const path = require('path');

const API_KEY = 'AIzaSyDWLYszu-Kx0_g7mWozF-iUE4wupgz16do';
const TELEGRAM_TOKEN = '7879596914:AAEzAU2Y5j_FkMGrdd5VQHHUA4-AVgJHZv4';
const TELEGRAM_CHAT_ID = '8087810997';
const TELEGRAM_API_URL = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`;
const urlsFilePath = path.join(process.env.WORKSPACE, 'domain_list.txt');

const BATCH_SIZE = 500;
const MAX_CONCURRENCY = 5;
const RETRY_LIMIT = 5;

function isMainDomain(hostname) {
  const parts = hostname.split('.');
  return parts.length === 2 || (parts.length === 3 && parts[1].length <= 3);
}

function generateVariants(url) {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname;
    const protocol = urlObj.protocol;
    const variants = new Set();

    variants.add(`${protocol}//${hostname}`);
    variants.add(`${protocol}//${hostname}/`);

    if (isMainDomain(hostname) && !hostname.startsWith('www.')) {
      variants.add(`${protocol}//www.${hostname}`);
      variants.add(`${protocol}//www.${hostname}/`);
    }

    return Array.from(variants);
  } catch {
    return [];
  }
}

function formatDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}

async function sendTelegramMessage(message) {
  try {
    await axios.post(TELEGRAM_API_URL, {
      chat_id: TELEGRAM_CHAT_ID,
      text: message,
      parse_mode: 'Markdown'
    });
  } catch (err) {
    console.error('发送 Telegram 消息失败：', err.message);
  }
}

async function checkHttpStatus(url) {
  try {
    const res = await axios.get(url, { maxRedirects: 5, timeout: 8000, validateStatus: () => true });
    return res.status;
  } catch {
    return 0;
  }
}

async function checkGoogleSafeBatch(urls) {
  for (let attempt = 0; attempt < RETRY_LIMIT; attempt++) {
    try {
      const res = await axios.post(
        `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEY}`,
        {
          client: { clientId: "mycompany", clientVersion: "1.0" },
          threatInfo: {
            threatTypes: ["MALWARE","SOCIAL_ENGINEERING","UNWANTED_SOFTWARE","POTENTIALLY_HARMFUL_APPLICATION"],
            platformTypes: ["ANY_PLATFORM"],
            threatEntryTypes: ["URL"],
            threatEntries: urls.map(u => ({ url: u }))
          }
        }
      );
      return res.data && res.data.matches ? true : false;
    } catch (err) {
      const wait = Math.pow(2, attempt) * 1000;
      console.warn(`Safe Browsing 请求失败，重试 #${attempt + 1} 等待 ${wait}ms`);
      await new Promise(r => setTimeout(r, wait));
    }
  }
  return false;
}

async function asyncPool(poolLimit, array, iteratorFn) {
  const ret = [];
  const executing = [];
  for (const item of array) {
    const p = Promise.resolve().then(() => iteratorFn(item));
    ret.push(p);

    if (poolLimit <= array.length) {
      const e = p.then(() => executing.splice(executing.indexOf(e), 1));
      executing.push(e);
      if (executing.length >= poolLimit) {
        await Promise.race(executing);
      }
    }
  }
  return Promise.all(ret);
}

async function checkUrls() {
  const fileContent = fs.readFileSync(urlsFilePath, 'utf-8');
  const lines = fileContent.split('\n');

  const projects = {};
  let currentProject = '未分组';

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    const match = trimmed.match(/^\[(.+?)\]$/);
    if (match) currentProject = match[1];
    else {
      if (!projects[currentProject]) projects[currentProject] = [];
      projects[currentProject].push(trimmed);
    }
  }

  for (const [project, urls] of Object.entries(projects)) {
    const red = new Set();
    const bad = new Set();
    const good = new Set();

    await asyncPool(MAX_CONCURRENCY, urls, async (url) => {
      const variants = generateVariants(url);
      const isUnsafe = await checkGoogleSafeBatch(variants);
      if (isUnsafe) {
        red.add(url);
        return;
      }

      const status = await checkHttpStatus(url);
      if (status === 200) good.add(url);
      else bad.add(url);
    });

    let output = `📦 ${project} 检测结果：\n`;

    if (good.size > 0) {
      output += '✅ 正常：\n';
      output += Array.from(good).map(formatDomain).join('\n') + '\n';
    }
    if (bad.size > 0) {
      output += '\n📡 异常：\n';
      output += Array.from(bad).map(formatDomain).join('\n') + '\n';
    }
    if (red.size > 0) {
      output += '\n🚨 危险：\n';
      output += Array.from(red).map(formatDomain).join('\n') + '\n';
      output += '⚠️ 已被 Google 判定为危险网站\n';
    }

//    let output = '';
//    
//    if (bad.size > 0 || red.size > 0) {
//        output = `📦 ${project} 检测结果：\n`;
//        if (bad.size > 0) output += `📡 异常：\n${Array.from(bad).map(formatDomain).join('\n')}\n`;
//        if (red.size > 0) output += `🚨 危险：\n${Array.from(red).map(formatDomain).join('\n')}\n`;
//    } else {
//        output = `📦 ${project} 检测结果：\n此次检测无异常`;
//    }

    output = output.trim();
    console.log(output);
    await sendTelegramMessage(output);
  }
}

checkUrls();

