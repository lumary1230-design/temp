import os
import json
import requests
import re
import time

# ======================
# 配置与 API 函数
# ======================
def load_config(config_file="config.json"):
    with open(config_file, "r") as f:
        return json.load(f)

def get_zone_id(api_token, domain):
    url = f"https://api.cloudflare.com/client/v4/zones?name={domain}"
    headers = {"Authorization": f"Bearer {api_token}", "Content-Type": "application/json"}
    resp = requests.get(url, headers=headers).json()
    if resp["success"] and resp["result"]:
        return resp["result"][0]["id"]
    return None

def delete_dns_records(api_token, zone_id):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records"
    headers = {"Authorization": f"Bearer {api_token}", "Content-Type": "application/json"}

    page = 1
    while True:
        params = {"page": page, "per_page": 100}
        resp = requests.get(url, headers=headers, params=params).json()
        if not resp["success"]:
            print(f"[-] 获取 DNS 记录失败: {resp}")
            break

        records = resp["result"]
        if not records:
            break

        for record in records:
            del_url = f"{url}/{record['id']}"
            del_resp = requests.delete(del_url, headers=headers).json()
            if del_resp["success"]:
                print(f"[+] 已删除: {record['name']} ({record['type']})")
            else:
                print(f"[-] 删除失败: {record['name']} → {del_resp}")

        page += 1

def create_dns_record(api_token, zone_id, record_type, name, content, proxied=True, ttl=120):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records"
    headers = {"Authorization": f"Bearer {api_token}", "Content-Type": "application/json"}
    data = {
        "type": record_type,
        "name": name,
        "content": content,
        "ttl": ttl,
        "proxied": proxied
    }
    return requests.post(url, headers=headers, json=data).json()

def purge_cache(api_token, zone_id):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/purge_cache"
    headers = {"Authorization": f"Bearer {api_token}", "Content-Type": "application/json"}
    data = {"purge_everything": True}
    return requests.post(url, headers=headers, json=data).json()

# ======================
# 工具函数
# ======================
def is_ip(addr):
    return bool(re.match(r"^\d{1,3}(\.\d{1,3}){3}$", addr))

# ======================
# 主流程
# ======================
if __name__ == "__main__":
    # 读取配置文件
    config = load_config("config.json")
    api_token = config["api_token"]

    # Jenkins 参数
    domains_text = os.getenv("DOMAINS", "")
    hosts_text = os.getenv("HOST", "")
    target = os.getenv("TARGET")

    # 解析多行
    domains = [line.strip() for line in domains_text.splitlines() if line.strip()]
    hosts = [line.strip() for line in hosts_text.splitlines() if line.strip()]

    if not domains:
        print("[-] 没有获取到域名，请检查 DOMAINS 参数")
        exit(1)
    if not hosts:
        print("[-] 没有获取到 HOST 参数")
        exit(1)
    if not target:
        print("[-] 没有获取到 TARGET 参数")
        exit(1)

    record_type = "A" if is_ip(target) else "CNAME"

    added_domains = set()
    added_records = []

    for domain in domains:
        zone_id = get_zone_id(api_token, domain)
        if not zone_id:
            print(f"[-] Zone {domain} 不存在，请先在 Cloudflare 添加该域名。")
            continue

        print(f"[!] 将删除 {domain} 下的所有 DNS 记录...")
        delete_dns_records(api_token, zone_id)

        added_domains.add(domain)

        for host in hosts:
            full_name = f"{host}.{domain}" if host != "@" else domain
            print(f"[+] 添加新解析 {full_name} → {target} ({record_type})")

            resp = create_dns_record(api_token, zone_id, record_type, full_name, target)
            if resp.get("success"):
                record_info = resp["result"]
                print(f"新增记录结果: 'name': '{record_info['name']}', 'type': '{record_info['type']}'")
                added_records.append(record_info["name"])
            else:
                print(f"[-] 新增失败: {resp}")

        # 清缓存
        purge_resp = purge_cache(api_token, zone_id)
        if purge_resp.get("success"):
            print(f"[+] {domain} 清缓存成功")
        else:
            print(f"[-] {domain} 清缓存失败 → {purge_resp}")

        time.sleep(1)

    # ======================
    # 汇总输出
    # ======================
    print("\n新增域名解析如下：")
    for d in added_domains:
        print(d)  # 主域名
        for h in hosts:
            full_name = f"{h}.{d}" if h != "@" else d
            print(f"{full_name}")  # 子域名记录加两个空格缩进
    
    print("\n新增记录如下")
    for r in added_records:
        print(f"{r}")  # 记录统一缩进两个空格
