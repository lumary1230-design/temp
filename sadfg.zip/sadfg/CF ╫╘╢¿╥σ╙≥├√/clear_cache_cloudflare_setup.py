import requests
import json
import sys

with open("config.json") as f:
    config = json.load(f)

API_TOKEN = config["api_token"]
ACCOUNT_ID = config["account_id"]
BASE_URL = "https://api.cloudflare.com/client/v4"

headers = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}

def get_main_domain(subdomain):
    parts = subdomain.strip().split(".")
    if len(parts) >= 2:
        return ".".join(parts[-2:])
    else:
        print(f"[错误] 无法识别主域名: {subdomain}")
        return None

def get_zone_id(domain):
    url = f"{BASE_URL}/zones?name={domain}&account.id={ACCOUNT_ID}"
    try:
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        result = r.json().get("result")
        if not result:
            print(f"[不存在] 找不到主域名 {domain} 的 Zone ID")
            return None
        return result[0]["id"]
    except Exception as e:
        print(f"[错误] 获取 Zone ID {domain} 失败: {e}")
        return None

def purge_cache(zone_id):
    url = f"{BASE_URL}/zones/{zone_id}/purge_cache"
    payload = {"purge_everything": True}
    try:
        resp = requests.post(url, headers=headers, json=payload)
        if resp.status_code == 403:
            print(f"[跳过清缓存] Zone {zone_id} 缺少权限")
            return False
        resp.raise_for_status()
        print(f"[清缓存] Zone {zone_id} 已清理")
        return True
    except Exception as e:
        print(f"[错误] 清缓存失败 Zone {zone_id}: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python script.py '域名列表(换行分隔)'")
        sys.exit(1)

    raw_domains = sys.argv[1].splitlines()
    domain_list = [d.strip() for d in raw_domains if d.strip()]

    processed_zones = set()

    for subdomain in domain_list:
        main_domain = get_main_domain(subdomain)
        if not main_domain:
            continue

        if main_domain in processed_zones:
            print(f"[跳过] {main_domain} 已清理过缓存")
            continue

        zone_id = get_zone_id(main_domain)
        if not zone_id:
            continue

        purge_cache(zone_id)
        processed_zones.add(main_domain)
