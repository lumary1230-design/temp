import requests
import json
import sys

DEFAULT_IP = "1.2.3.4"

with open("config.json") as f:
    config = json.load(f)

API_TOKEN = config["api_token"]
ACCOUNT_ID = config["account_id"]
BASE_URL = "https://api.cloudflare.com/client/v4"

headers = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}

def get_zone_id(domain):
    url = f"{BASE_URL}/zones?name={domain}&account.id={ACCOUNT_ID}"
    try:
        r = requests.get(url, headers=headers)
        r.raise_for_status()
        result = r.json().get("result")
        if not result:
            print(f"[不存在] 找不到主域名 {domain} 的 Zone ID")
            return None
        return result[0]["id"]
    except Exception as e:
        print(f"[错误] 获取 Zone ID {domain} 失败: {e}")
        return None

def get_main_domain(subdomain):
    parts = subdomain.strip().split(".")
    if len(parts) >= 2:
        return ".".join(parts[-2:])
    print(f"[错误] 无法识别主域名: {subdomain}")
    return None

def update_dns_record(zone_id, record_name, ip):
    try:
        search_url = f"{BASE_URL}/zones/{zone_id}/dns_records?name={record_name}"
        resp = requests.get(search_url, headers=headers).json()
        if resp["result"]:
            record_id = resp["result"][0]["id"]
            update_url = f"{BASE_URL}/zones/{zone_id}/dns_records/{record_id}"
            payload = {"type": "A", "name": record_name, "content": ip, "ttl": 120}
            requests.put(update_url, headers=headers, json=payload).raise_for_status()
            print(f"[更新] {record_name} -> {ip}")
        else:
            create_url = f"{BASE_URL}/zones/{zone_id}/dns_records"
            payload = {"type": "A", "name": record_name, "content": ip, "ttl": 120}
            requests.post(create_url, headers=headers, json=payload).raise_for_status()
            print(f"[新增] {record_name} -> {ip}")
        return True
    except Exception as e:
        print(f"[错误] 更新/新增解析 {record_name} 失败: {e}")
        return False

def purge_cache(zone_id):
    try:
        url = f"{BASE_URL}/zones/{zone_id}/purge_cache"
        payload = {"purge_everything": True}
        resp = requests.post(url, headers=headers, json=payload)
        if resp.status_code == 403:
            print(f"[跳过清缓存] Zone {zone_id} 缺少权限")
            return False
        resp.raise_for_status()
        print(f"[清缓存] Zone {zone_id} 已清理")
        return True
    except Exception as e:
        print(f"[错误] 清缓存失败 Zone {zone_id}: {e}")
        return False

def delete_zone(zone_id, main_domain):
    try:
        url = f"{BASE_URL}/zones/{zone_id}"
        resp = requests.delete(url, headers=headers)
        if resp.status_code == 200:
            print(f"[删除域名] {main_domain} 已从 Cloudflare 移除")
            return True
        elif resp.status_code == 403:
            print(f"[跳过删除域名] {main_domain} 缺少删除权限")
            return False
        else:
            resp.raise_for_status()
    except Exception as e:
        print(f"[错误] 删除域名 {main_domain} 失败: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python script.py '域名列表(换行分隔)'")
        sys.exit(1)

    raw_domains = sys.argv[1].splitlines()
    domain_list = [d.strip() for d in raw_domains if d.strip()]

    for subdomain in domain_list:
        main_domain = get_main_domain(subdomain)
        if not main_domain:
            continue

        zone_id = get_zone_id(main_domain)
        if not zone_id:
            continue

        # 先更新或新增解析
        if not update_dns_record(zone_id, subdomain, DEFAULT_IP):
            continue

        # 清缓存（权限不足跳过）
        purge_cache(zone_id)

        # 删除整个域名 Zone
        delete_zone(zone_id, main_domain)

