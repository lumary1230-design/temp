import requests
import json
import sys
import re

def load_config():
    with open("config.json", "r") as f:
        return json.load(f)

def get_zone_id(domain, headers):
    url = f"https://api.cloudflare.com/client/v4/zones?name={domain}"
    resp = requests.get(url, headers=headers).json()
    if resp["success"] and resp["result"]:
        return resp["result"][0]["id"]
    raise Exception(f"无法获取 Zone ID: {domain}，响应: {resp}")

def create_zone(domain, account_id, headers):
    url = "https://api.cloudflare.com/client/v4/zones"
    data = {
        "name": domain,
        "account": {"id": account_id},
        "jump_start": False
    }
    resp = requests.post(url, headers=headers, json=data).json()
    if resp["success"]:
        print(f"✅ 添加域名成功: {domain}")
    else:
        raise Exception(f"添加域名失败: {domain}，响应: {resp}")

def is_ip(target):
    return re.match(r"^\d{1,3}(\.\d{1,3}){3}$", target) is not None

def add_dns_record(zone_id, headers, record_name, target):
    record_type = "A" if is_ip(target) else "CNAME"
    data = {
        "type": record_type,
        "name": record_name,
        "content": target.strip(),
        "proxied": True
    }
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records"
    resp = requests.post(url, headers=headers, json=data).json()
    if resp["success"]:
        print(f"✅ 添加解析: {record_name} -> {target} ({record_type})")
    else:
        print(f"❌ 添加解析失败: {record_name}，响应: {resp}")

def set_ssl_mode(zone_id, headers):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/settings/ssl"
    resp = requests.patch(url, headers=headers, json={"value": "flexible"}).json()
    if resp["success"]:
        print("✅ 设置 SSL 模式为 flexible")
    else:
        print(f"❌ 设置 SSL 模式失败: {resp}")

def enforce_https(zone_id, headers):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/settings/always_use_https"
    resp = requests.patch(url, headers=headers, json={"value": "on"}).json()
    if resp["success"]:
        print("✅ 启用 HTTPS 强制跳转")
    else:
        print(f"❌ 启用 HTTPS 强制跳转失败: {resp}")

def block_country(zone_id, headers, countries):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/firewall/rules"
    expr = " or ".join([f'(ip.geoip.country eq "{c}")' for c in countries])
    payload = [{
        "filter": {
            "expression": expr,
            "paused": False,
            "description": "Block countries"
        },
        "action": "block",
        "description": f"Block traffic from {', '.join(countries)}"
    }]
    resp = requests.post(url, headers=headers, json=payload).json()
    if resp["success"]:
        print(f"✅ 屏蔽国家: {', '.join(countries)}")
    else:
        print(f"❌ 屏蔽国家失败: {resp}")

def redirect_root_to_www(zone_id, headers, domain):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/rulesets"
    data = {
        "name": "Redirect root to www",
        "description": "Redirect root domain to www",
        "kind": "zone",
        "phase": "http_request_dynamic_redirect",
        "rules": [
            {
                "enabled": True,
                "action": "redirect",
                "action_parameters": {
                    "from_value": {
                        "status_code": 301,
                        "target_url": {
                            "expression": f'concat("https://www.{domain}", http.request.uri)'
                        }
                    }
                },
                "expression": f'http.host == "{domain}"'
            }
        ]
    }
    resp = requests.post(url, headers=headers, json=data).json()
    if resp.get("success"):
        print(f"✅ 设置 {domain} → www.{domain} 跳转规则成功")
    else:
        print(f"❌ 设置跳转规则失败: {resp}")

def main():
    config = load_config()
    token = config["api_token"]
    account_id = config["account_id"]

    if len(sys.argv) < 4:
        print("❌ 参数不足: python script.py <domain1 domain2> <host1 host2> <target>")
        sys.exit(1)

    domains = sys.argv[1].split()
    subdomains = sys.argv[2].split()
    target = sys.argv[3]

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    for domain in domains:
        print(f"\n🚀 处理域名: {domain}")
        try:
            try:
                zone_id = get_zone_id(domain, headers)
            except:
                create_zone(domain, account_id, headers)
                zone_id = get_zone_id(domain, headers)

            for sub in subdomains:
                full_name = domain if sub == "@" else f"{sub}.{domain}"
                add_dns_record(zone_id, headers, full_name, target)

            set_ssl_mode(zone_id, headers)
            enforce_https(zone_id, headers)

            # 查询DNS，检测@和www
            dns_url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records"
            dns_res = requests.get(dns_url, headers=headers).json()

            has_root = any(r["name"] == domain for r in dns_res["result"])
            has_www = any(r["name"] == f"www.{domain}" for r in dns_res["result"])

            if has_root and has_www:
                print("🔁 检测到 @ 和 www，设置根域跳转到 www")
                redirect_root_to_www(zone_id, headers, domain)

            block_country(zone_id, headers, ["CN"])
            #block_country(zone_id, headers, ["CN","RU"])

        except Exception as e:
            print(f"❌ 处理 {domain} 出错: {e}")

if __name__ == "__main__":
    main()
