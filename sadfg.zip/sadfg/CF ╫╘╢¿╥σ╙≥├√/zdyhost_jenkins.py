import os
import json
import requests
import sys

CONFIG_FILE = 'zdyhost_config.json'

# 读取 config 配置
try:
    with open(CONFIG_FILE, 'r') as f:
        config = json.load(f)
        EMAIL = config.get('email')
        API_KEY = config.get('api_key')
except Exception as e:
    print(f"❌ 读取配置文件失败: {e}")
    sys.exit(1)

if not EMAIL or not API_KEY:
    print("❌ 配置文件中缺少 email 或 api_key")
    sys.exit(1)

# 读取 Jenkins 环境变量
ZONE_NAME = os.environ.get('ZONE_NAME')  # 主域名
CUSTOM_HOSTNAMES_RAW = os.environ.get('CUSTOM_HOSTNAMES')  # 多行自定义主机名

if not ZONE_NAME:
    print("❌ 环境变量 ZONE_NAME（主域名）未设置")
    sys.exit(1)

if not CUSTOM_HOSTNAMES_RAW:
    print("❌ 环境变量 CUSTOM_HOSTNAMES（自定义主机名）未设置")
    sys.exit(1)

# 处理自定义主机名列表
hostnames = [h.strip() for h in CUSTOM_HOSTNAMES_RAW.strip().splitlines() if h.strip()]
if not hostnames:
    print("❌ 没有有效的自定义主机名")
    sys.exit(1)

API_BASE = 'https://api.cloudflare.com/client/v4'
HEADERS = {
    'X-Auth-Email': EMAIL,
    'X-Auth-Key': API_KEY,
    'Content-Type': 'application/json'
}

# 获取 Zone ID
print(f"🔍 获取主域名 {ZONE_NAME} 的 Zone ID...")
zone_resp = requests.get(
    f"{API_BASE}/zones",
    headers=HEADERS,
    params={"name": ZONE_NAME, "status": "active"}
)

try:
    zone_json = zone_resp.json()
    ZONE_ID = zone_json["result"][0]["id"]
except Exception:
    print("❌ 无法获取 Zone ID，请确认主域名是否存在并激活")
    sys.exit(1)

print(f"✅ 获取成功，ZONE_ID = {ZONE_ID}")

# 批量添加自定义主机名
for hostname in hostnames:
    print(f"▶ 添加自定义主机名: {hostname}")

    data = {
        "hostname": hostname,
        "ssl": {
            "method": "http",
            "type": "dv",
            "settings": {
                "http2": "on",
                "tls_1_3": "on",
                "min_tls_version": "1.2"
            }
        }
        # 注意：不设置回源服务器 fallback_origin，使用默认设置
    }

    resp = requests.post(
        f"{API_BASE}/zones/{ZONE_ID}/custom_hostnames",
        headers=HEADERS,
        json=data
    )

    try:
        resp_json = resp.json()
    except Exception:
        print(f"❌ 响应非 JSON 格式，HTTP 状态码: {resp.status_code}")
        continue

    if resp.status_code in (200, 201) and resp_json.get('success'):
        print(f"✅ 添加成功: {hostname}")
    else:
        errors = resp_json.get('errors', [])
        messages = "; ".join(e.get('message', '') for e in errors) or "未知错误"
        print(f"❌ 添加失败: {hostname}，错误: {messages}，HTTP 状态码: {resp.status_code}")

print("✅ 所有自定义主机名处理完成。")

